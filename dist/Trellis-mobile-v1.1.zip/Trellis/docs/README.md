# 文档索引（从这里开始读）

> 这个目录里既有**需求/机制**（要遵守），也有**调研结论**（可引用）、**历史记录**（只供追溯）。
> 先看下面的「文档地图」，再按「阅读路径」挑要读的；别从 `kernel-design.md` 第一行硬读到底——它是词典，不是教程。

## 文档地图

| 文件 | 讲什么 | 性质 | 什么时候读 |
|---|---|---|---|
| [`../AGENTS.md`](../AGENTS.md) | **工程入口**：模块 → 源码路径 → 改什么去哪 | 活文档（最该先读） | 任何改动之前 |
| [`../README.md`](../README.md) | 项目简介、构建命令、插件/权限/存储速览、14 条铁律 | 活文档 | 第一次接触项目 |
| [`kernel-design.md`](kernel-design.md) | 内核完整设计：分层、模块边界、抽象定义、9 个挂载点、启动序列、失败隔离、快照回滚、错误码、契约测试、里程碑、反模式 | **机制参考**（v0.1 Draft；部分章节未实现/已偏离，文首有现状提示，冲突时以代码为准） | 改内核 / 需要确认不变量 / 判断某个设计该不该做 |
| [`agent-manager.md`](agent-manager.md) | AI 管理员：分层提示词（缓存友好）、意图路由、工具链、界面即插件、岗位色、点阵与表格、会话不露协议壳、多步任务清单、B 站学习资源工具 | 活文档 | 改 AI 层、加工具、排查「AI 为什么不做/做错」 |
| [`agent-harness.md`](agent-harness.md) | **Agent Harness 重构方案**：为什么撤销「按消息意图裁工具」、成熟 harness 的稳定工具集 + 权限分级模式、目标架构（工具风险表 / 审批 / 单一提示词）、A/B 迁移与 eval 门槛（方向已定，P1 待开工） | **方案（Draft v0.2，已拍板方向）**（2026-10-30） | 讨论意图路由、工具越界/死胡同、审批与写操作边界之前；P1 实验开工前 |
| [`agent-workflow-ui.md`](agent-workflow-ui.md) | Agent 工作流清单的**设计说明**：放哪、数据模型、工具契约、状态机、视觉规格、明确不做什么、已知缺口 | 实现记录（2026-10-26） | 改清单 UI / 讨论 `set_plan` 语义 / 加步骤状态 |
| [`plan-backend.md`](plan-backend.md) | 学习计划后端（事件溯源 + SQLite）：模块分工、与设计稿的差异、命令语义、测试、P3/P4 待接 | 实现记录（2026-10-26） | 改 `:features:learning-process` / 接 UI / 加 plan 工具 |
| [`plan-page.md`](plan-page.md) | 计划页：上半一周一格、下半选中周的那一天；数据全部来自 plan 后端的 view model | 实现记录（2026-10-27） | 改计划页 / 接视图 / 讨论「周视图该显示什么」 |
| [`focus-timer.md`](focus-timer.md) | 计时器小窗：为什么独立窗口、倒计时（有进度条）/ 正计时（无进度条）、结束记入分钟数、边界与验证 | 实现记录（2026-10-28） | 改计时器 / 讨论「计时要不要进主窗口」 |
| [`activity.md`](activity.md) | 活动分类：AW 原始事件 → SQLite → 分层分类（大类/小类/颜色/规则优先级）→ 日汇总；标签页 URL 匹配、时间口径、已知缺口 | 实现记录（2026-10-29） | 改 `:features:activity` / 接分类 UI / 做任务与计划追溯 |
| [`time-conventions.md`](time-conventions.md) | **时间与时钟规范**：墙钟/单调钟、唯一时间源 `TrellisClock`、ISO 周与时区、后端注入契约、开发者跳日期、时间逻辑的测试要求、存量迁移批次与自检清单 | **规范（要遵守）**（2026-10-29） | 任何涉及「今天/本周/跨周/时长/超时」的改动之前；新同学进计划/活动/计时器相关代码前 |
| [`steward.md`](steward.md) | **管家会话**：置顶常驻会话 + 晨/夜仪式（幂等、合并规则、模板兜底、跨平台桌面通知）+ 记忆（append-only jsonl + 每日摘要，先不做语义检索）+ 建议卡（模板生成改动 → 一键采纳/调整/先这样，采纳直接调后端命令）；含数据目录、设置页、代码地图与测试 | 实现记录（2026-11-03，P1） | 改管家/晨夜消息/通知/建议卡前；讨论「主动 AI 反馈」时 |
| [`conversation-redesign.md`](conversation-redesign.md) | 会话页五层信息、三态、三动作、撤销语义 | 实现记录（2026-10-24） | 改会话页 UI / 理解「过程与结论分离」 |
| [`roadmap.md`](roadmap.md) | 已知缺口与优先级（能力面、视觉、插件市场、端） | 活文档 | 动手前先查有没有人记过这个坑 |
| [`eval-prompts.md`](eval-prompts.md) | 验收题库（送检用，与提示词里的示例互为镜像） | 活文档（测试配套） | 调提示词后自测、验收 AI 能力 |
| [`examples/bento-style.md`](examples/bento-style.md) | 样片「Bento / BENTO SHIFT」怎么拆成三层落进 Trellis | 实现记录 | 做主题/看板类插件、理解「样式/数据/外壳」边界 |
| [`plugin-hotplug-path.md`](plugin-hotplug-path.md) | 跨平台 + 插件运行时热插拔的成熟路径调研结论（TL;DR、候选矩阵、推荐路径、落地计划、风险） | **结论冻结**（v1.0，2026-10-22） | 讨论 Android/iOS、热更新、插件市场前 |
| [`research/plugin-hotplug/01-sandbox-runtimes.md`](research/plugin-hotplug/01-sandbox-runtimes.md) | JS/Wasm 沙箱运行时调研（Zipline / quickjs-kt / Chicory / Chasm / Rhino / GraalJS…） | 调研证据 | 选运行时、评估平台矩阵 |
| [`research/plugin-hotplug/02-native-loaders.md`](research/plugin-hotplug/02-native-loaders.md) | 原生插件加载（PF4J / Shadow / ClassLoader、iOS 约束） | 调研证据 | 桌面/Android/iOS 原生插件方案 |
| [`research/plugin-hotplug/03-oss-case-studies.md`](research/plugin-hotplug/03-oss-case-studies.md) | 14 个开源案例（VS Code / JetBrains / Figma / Obsidian / Chrome / Blender / Neovim / Emacs / Godot / Unity / Slack / Cloudflare / Shopify / Istio） | 调研证据 | 找成熟模式（贡献点、激活事件、卸载契约…） |
| [`research/plugin-hotplug/04-app-update-policy.md`](research/plugin-hotplug/04-app-update-policy.md) | 应用级更新（桌面 MSIX/Sparkle、移动商店、Apple PLA、Google Play 政策） | 调研证据 | 做发布/更新/商店合规 |
| [`research/learning.md`](research/learning.md) | 学习科学与行为设计证据简报（自主/胜任/关系、实施意向 d=0.65、外部奖励 d=−0.40…） | 调研证据（2026-10-26） | 决定奖励/连续天数/计划文案前 |
| [`research/product.md`](research/product.md) | 产品 / 主动性 HCI / 伦理证据简报（Duolingo streak、通知疲劳、付费结构、Khanmigo 追问翻车） | 调研证据（2026-10-26） | 做主动性、推送、定价、AI 语气前 |
| [`research/tech.md`](research/tech.md) | 技术选型证据简报（记忆框架、sqlite-vec、中文 embedding、GraphRAG、隐私与追踪、视觉、LLM 工程） | 调研证据（2026-10-26） | 选依赖、评估本地优先/隐私边界前 |
| [`assets/icons/`](assets/icons/) | 自绘像素风图标 SVG（导航用） | 资产 | 改导航图标 |
| [pluginization-plan-2026-10-29.md](pluginization-plan-2026-10-29.md) | 革新插件化计划草记：AGENT 如何核验与定完成标准、学习终端与知识体系图、目标转能力地图 | 构想草记（2026-10-29，未整理） | 讨论产品方向 / 知识体系时 |
| [plan-rhythm-draft.md](plan-rhythm-draft.md) | 「计划自己推进」（插件化计划第 1 条）的讨论稿：现状解剖（路线只排一部分、第 3 周断流、结算/复盘死代码、核验只有手动勾）、周滚动节奏引擎、完成核验分级、Agent 计划工具、分阶段落地 | 讨论稿（2026-10-29，未定稿） | 讨论「让计划自己推进」/ 接计划工具 / 做周滚动与核验前 |
| [knowledge-base-draft.md](knowledge-base-draft.md) | 「学习终端 + 知识库」（插件化计划第 2 条）的讨论稿：点亮 = 笔记里出现过的概念、文件为真相/索引可重建、内置 Markdown 编辑器 + 外部导入、不做掌握度与全局图、与计划解耦；已落地导航第三项「知识库」+ Markdown 编辑器 + 概念抽取/点亮/追溯/搜索 + 空位 AI 补全（`标签：。。。`）、AI 内容绿引号标记、整篇单字段 Markdown 编辑器 + 行内 WYSIWYG（点哪落哪、标题/引用前缀在光标行显示源码、链接只显示 label、跨行拖选与全选交给平台，§12）、中文伪粗体 + 行内代码圆角芯片、`[[概念]]` 显式语法 + AI 抽取自动首次打标（概念不设上限；AI 整理只在焦点离开正文时触发，AI 标记/补全不算更新）、导出当前笔记为独立 Markdown | 讨论稿（2026-10-29）；P0 已落地（2026-10-30 两批 + 2026-10-31 第三至七批 + 2026-11-01 排版/概念语法/AI 解析时机补丁 + 2026-11-02 整篇单字段编辑器） | 讨论知识库 / 做笔记与概念索引前 |
| [knowledge-graph-design.md](knowledge-graph-design.md) | 「知识网络」设计稿（插件化计划第 2 条第二期，v1.3）：默认视图=分类树（父节点是概念的所属；画布只有节点和父子连线，分类=空心虚节点、概念=实节点），聚焦节点弹小浮窗放信息，其它关系只在聚焦时出现；实节点没有上级时用「＋ 虚节点」建节点再拖到目标上建立父子链接；笔记页可用「保存并整理」按笔记标题结构（大标题→父分类，可概括）生成建图建议；「分层」=分类深度、交给 AI 不预制（旧依赖分层降级为 G2 可选「体系视图」）；节点/边/证据 + 三类事实（笔记派生/用户策展/AI 建议）；AI 归类与关系建议只出建议、用户逐条确认（墓碑/缓存失效/双 json）；知识页第三视图（宿主 Canvas 自绘、不碰内核/插件词汇表）；G0/G1/G2 分期、约 70 条纯函数测试、风险与待拍板问题；附录 E 有 G0/v1.2/v1.3/G1 实现记录 | **设计稿（2026-11-02 拍板；2026-11-03 G0→v1.2→v1.3→G1→补丁 4 已落地）** | 讨论/实现知识网络前；接计划节点↔概念、AI 知识工具前 |

## 阅读路径

- **第一次来，只想跑起来**：`../AGENTS.md` §1 → `../README.md` 构建与测试 → 跑 `:app:desktop:run`。
- **要改内核**：`kernel-design.md` §0（怎么用这份文档）→ §2 词汇表 → §3 模块边界 → §4 抽象 → §9 挂载点 → 再动代码；配合 `kernel/src/commonTest/.../api/*` 理解契约。
- **要改 AI 层**：`agent-manager.md` 全文 → `ai/.../manager/ManagerPrompt.kt` 与 `ManagerAgent.kt` → `eval-prompts.md` 自测；要动工具注入/审批边界，先读 `agent-harness.md`（方向已定，P1 待开工）。
- **要改工作流清单**：`agent-workflow-ui.md`（设计取舍与状态机）→ `WorkflowTools.kt` / `AppRuntime.beginPlan` / `ChatScreen.PlanChecklist`。
- **要改学习计划后端**：`plan-backend.md`（模块分工与语义）→ `sdk-domain/.../plan/Contract.kt` → `SqliteLearningPlanService.kt` + `PlanCommands.kt` → `LearningPlanServiceTest`。
- **要改计划页**：`plan-page.md`（结构、数据来源、已知缺口）→ `PlanScreen.kt` → `AppRuntime.refreshPlan`。
- **要让计划自己推进 / 接计划工具**：`plan-rhythm-draft.md`（背景与分阶段方案）→ `plan-backend.md` §8（`advanceRhythm` 契约）→ `PlanAdvance.kt` / `AppRuntime.refreshPlan` / `PlanAdminTools.kt`。
- **要讨论知识库 / 做笔记与概念索引**：`knowledge-base-draft.md`（口径、数据模型、P0/P1/P2）。
- **要做知识网络 / 概念间关系**：`knowledge-graph-design.md`（分类树+浮窗+拖动链接、三类事实、AI 只建议、双 json 存储、G0/G1/G2、测试与附录 E 实现记录）→ `knowledge-base-draft.md` §2/§3（概念/笔记/出处口径）→ `KnowledgeStore.kt`。
- **要改活动分类 / 时间汇总**：`activity.md`（规则语义、时间口径、已知缺口）→ `ActivityTaxonomy.kt` / `ActivityAggregator.kt` → `:features:activity:test`。
- **要碰「今天/本周/跨周/时长/超时」**：`time-conventions.md`（规范，先读 §0 和 §8）→ 计划链路看 `LearningPlanRhythmTest` → 要调试时间推移看 §7（开发者跳日期）。
- **要改界面/主题/布局**：`../AGENTS.md` §3「按问题找文件」→ `examples/bento-style.md`（三层边界）→ `conversation-redesign.md`（若改会话页）。
- **要动跨端/热更新**：`plugin-hotplug-path.md` §0 TL;DR → 对应 research 分册；别从零再调研一遍。
- **要决定「奖励/连续天数/主动性/推送/定价」**：`research/learning.md` + `research/product.md`（证据在前，别凭直觉）。
- **要选依赖或碰本地数据/隐私**：`research/tech.md`（记忆框架、sqlite-vec、embedding、GraphRAG 的取舍与来源）。
- **要发布**：`research/plugin-hotplug/04-app-update-policy.md` + 主文档 §6「热更新两层」。

## 维护约定

1. **活文档**（README、AGENTS、roadmap、agent-manager、eval-prompts）：改代码时顺手改，不要求文采，要求准确。
2. **冻结文档**（plugin-hotplug-path、research/*）：只追加勘误，不改结论；结论变了要新开一份。
3. **实现记录**（conversation-redesign、bento-style）：写「为什么这么定」，不写 API 清单（API 看代码）。
4. 文档里的路径一律写**仓库相对路径**；跨目录引用用相对链接，保证点得开。
5. 大文档查起来慢：用关键词定位（如 `RENDERED_MOUNT_POINTS`、`KernelPoints`、`capability`），不要通读。
