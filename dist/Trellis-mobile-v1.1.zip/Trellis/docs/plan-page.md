# 计划页（实现记录 · 2026-10-27）

> 一句话：**上面是整个计划，一周一格；下面是选中那周的选中一天，按待办的样子排。**
> 页面本身不算账，数字全部由 `:features:learning-process` 算好。

## 1. 为什么单独开一页

任务页回答「今天要做什么」，学生真实的问题是「这六周到底怎么走、这周该学什么」。
把它塞进首页卡片会变成第二张待办清单；它需要的是**周维度的总览**＋**落到某一天的安排**，
所以给它一个独立页签（左栏导航叫「计划」）。

## 2. 页面结构

```
┌ 计划 │ 计划  操作系统 · 一周一格，点开看那一天                    2 周 ┐
│ 计划        │ 总览 按周排                                              │
│ 未分类      │  [第 1 周 本周] [待安排 9 个节点] ← 半宽灰卡，点开看明细  │
│  · 操作系统…│   已排的：章节 / 2–3 个单元 / 日期范围 / 件数            │
│             ├ 待安排 · 9 个节点（合计 225 分钟 · 按每天 60 分钟约 4 天）│
│             │   第1章 计算机系统概述                                   │
│             │   ☐ P5 运行机制                        20 分钟           │
│             ├ 周三28 (今天•) | 周四29 | … | 周日1                       │
│             ├ 今天 2 件事，先做 P2 操作系统的概念、功能和目标。          │
│             │   ☐ P2 操作系统的概念、功能和目标  20 分钟   待做         │
└─────────────┴──────────────────────────────────────────────────────────┘
```

- 左侧是计划列表：按大类分组（`plans/categories.json` 里没有的算「未分类」）。
  点一行只看那一个计划。原来的「所有计划」汇总行已删除（既尴尬又点不动）。
- 周卡片标题是「第 N 周」（不把 ISO 周号摆到台面上），下面一行是这一周出现最多的章节名；
  再下面是单元名前三条；底部是 `rangeLabel` 与单元数。选中卡片描边加粗。
- **没排到具体某天的周不出周卡**：它的单元并入「待安排」集合，地图上只留**一张**半宽灰卡
  （`PendingWeekCard`，98dp = 周卡的一半，`surfaceVariant` 加 1dp 描边，顶部实心「待安排」胶囊），
  中间是待安排节点数，底部「点开看」。点开后在下方列明细（`PendingDetail`）：
  合计分钟 + 按每天投入算「约 N 天」+ 按章节分组的节点与各自预计时间。
- 天条七格等宽，今天的格子里有个点和「今天」的语义（`WeekDay.today`）；空格显示 `—`。
- 下方正文来自 `DayView`：`headline`（后端写好的整句）+ `occurrences`（待做，可勾）
  + `completed`（已完成，带删除线）。勾选直接调 `completeOccurrence`。
- 天条上写的「N 件」与正文口径一致：当天 planned 与当天完成的都算（`doneScheduledOn` 补的那部分）。
- 节点行不再显示「最小版 N 分 / 待做」，统一只显示「待做」。

## 3. 数据从哪来

| 界面要什么 | 调哪个 | 来源 |
|---|---|---|
| 计划标题、当前周、周列表 | `activePlanId()` + `planState()` + `map()` | `:features:learning-process`（SQLite 事件库） |
| 每张周卡片 | `week(planId, week)` → `commitment.units` | 同上 |
| 七天的格子 | `week(...)` → `days` | 同上 |
| 某一天正文 | `today(planId, day)` → `DayView` | 同上 |
| 勾掉一条 | `completeOccurrence(envelope, occurrenceId)` | 命令层；写完重取整页 |

运行时侧只有这几个字段（`AppRuntime`）：`planTitle` / `planWeekCards` / `planDays` /
`planSelectedWeek` / `planSelectedDay` / `planDayView` / `planMessage`；
`refreshPlan()` 一次取齐，`selectPlanWeek` / `selectPlanDay` / `completePlanOccurrence` 三个动作。

**不在页面里做的事**：算完成率、算还剩几件、判断是否逾期、拼「今天一件事」这句话——
这些都属于后端（`plan-backend.md` 的硬规则：只有 `ReviewView` 带统计，别的视图只给文案）。

## 4. 库打不开时

`<trellis home>/plans/plan.db` 只在这一页第一次打开时建连（`LearningPlanStore.open`）。
打不开就在页面上直说（`planMessage`），不假装「今天没事」。没有计划时给一句
「在对话里说『我想学 xx，帮我排个计划』」，指向真正能造计划的地方（AI 管理员 + 计划工具）。

## 5. 已知缺口

1. **只能看图，不能改计划**：调整承诺、顺延、拆分、缩短都还没有入口（后端已有命令）。
2. **没有周复盘**：`ReviewView` 与 `generateReview` 还没接；周卡片右上角可以加「复盘」入口。
3. **时区**：`today(planId, day)` 的 `day` 用系统本地日期；跨时区场景要按 `plan-ui-contract.md` 再定。
4. **勾选后的落点**：`completed` 按 `completed_at` 的日期归档，所以「28 号的事今天做完」不会留在
   28 号那一格里（会出现在今天）。这是后端的口径，界面暂时照它显示；如果嫌怪，改的是命令层而不是页面。

## 6. 验证

- `:app:desktop:compileKotlin` / `:app:desktop:test` / 全仓 `gradlew test` 均绿。
- 演示数据：`_shots/plan-home/plans/plan.db`（一次性造数脚本已删），
  启动 `TRELLIS_HOME=_shots/plan-home TRELLIS_TAB=plan` 截图核对周卡片、天条、勾选。

## 7. 2026-10-27 晚的三处修正

1. **删掉「所有计划」那一行**：它在只有几个计划时没有信息量，而且 `selectPlan(null)` 的选中态
   和「未分类」标题叠在一起看着像坏了。现在左侧只有：分类标题 + 计划行。
2. **完成可以改回没做**：已完成行现在可点（行尾提示「点一下可以改回没做」），
   走 `uncompleteOccurrence`：`done → planned` 并把 `completed_at` 清空
   （表 CHECK 要求两者一致），写 `occurrence.uncompleted` 事件。不依赖 5 秒撤销窗口。
3. **第一周落在过去**（2026-11-03 已删除，见 §14）：根因是模型把周次写成上一年（`2025-W01`），而工具没拦。
   - `PlanTools.create_learning_plan` 现在拒绝早于本周的 ISO 周，报错里直接给「从本周 Wxx 开始」；
   - 计划页检测到 `planStartsInPast` 时在顶上给一条横幅 + 「挪到本周」按钮：
     不改旧计划（`plan_version` 不可变、occurrence 身份不可改），而是建一份新计划把单元按原顺序
     搬过来、结束旧计划；旧计划保留在库里，历史不丢。
   - 覆盖测试：`LearningPlanServiceTest.aCompletedOccurrenceCanBeMarkedUndoneOnPurpose`（完成→改回）；
     `PlanRepairTest` 已于 2026-11-03 随横幅删除。

## 8. 2026-10-27 夜：挪到本周不再新建计划 + 计划从今天起排

1. **「挪到本周」改成原地修**（用户报：点一下多出一个新计划；2026-11-03 已删除，见 §14）
   - 旧做法：建一份「（重排）」新计划，再结束旧计划 → 左侧出现两条计划，完成记录留在旧计划里。
   - 新做法：`AppRuntime.repairPastPlan()` 在**原计划**里 `saveDraft → acceptDraft` 出一版周次平移后的版本：
     同一个 `planId`、同一个标题、同一批单元；旧版本作为历史留在库里，不删也不改。
   - 顺带修 `PlanQueries.buildMapView`：总览的周列表原来跨所有版本取 `DISTINCT c.week`，
     重排后 `2025-W01` 会和本周同时出现（并让「过去」横幅消不掉）；现在只认 `plan.current_version_id`。
   - 左侧列表只列未结束的计划，副标题改成「进行中 / 草稿」，不再原样显示 `active`。
2. **计划第一周必须是本周**（用户报：agent 排计划不以当天为准）
   - `PlanTools.create_learning_plan`：第一周必须等于今天所在的 ISO 周，否则报错并给出本周；
     `weeks` 还要求按时间递增、不重复。
   - 排期本身早就是「从今天铺」：`materializeWeek` 里 `day = if (today in 本周) today else 周一`。
     之前从下周开始，是模型把 `weeks[0]` 直接写成了下周，工具没拦。
   - 测试：`PlanToolsTest.aPlanThatStartsNextWeekIsRejected`（新增；创建时校验保留）。`PlanRepairTest` 已随横幅删除。
3. **数据清理**：旧逻辑在真实 home 里留下的重复计划已整理为「一条 active、两条 ended」；
   原库备份在 `~/.trellis/plans/plan.db.bak-20261027-2240`。

## 9. 2026-10-28：待安排收成一张卡、按每天投入排期、计划设置

1. **待安排不再是一排灰周卡**
   - 没排到具体某天的周不出周卡：它们的单元并入「待安排」集合（和 `pool()` 里没分到周的单元去重合并）。
   - 总览末尾只有一张半宽卡：`PendingWeekCard` 98dp（周卡 196dp 的一半）、`surfaceVariant` 底 + 1dp 描边、
     顶部实心「待安排」胶囊、中间节点数、底部「点开看」。
   - 点开后下方换成「待安排 · N 个节点」：合计分钟 +「按每天 60 分钟算，约 N 天」+ 按章节分组的节点与预计时间。
   - 运行时字段：`AppRuntime.planPendingNodes`、`planPendingSelected`、`selectPlanPending()`。
2. **排期按每天投入分钟数打包**
   - `PlanStateView.dailyMinutes`（= `process.weekly_capacity_minutes / 7`）。
   - `materializeWeek` 按每天预算塞（20+25 同一天，超过预算换下一天；单单元超预算独占一天）。
   - 没设过投入时间的计划保持旧规矩「一天一个」，不猜容量。
3. **计划设置（计划级属性，不是全局设置）**
   - 入口：计划页头部右侧「计划设置」文字按钮（有当前计划才出现）。
   - 弹窗：`PlanSettingsDialog` ——「只改当前这个计划（标题）；换一个计划就是另一套。」、
     −/＋ 调 15–240、预设 30′/45′/60′/90′/120′、说明「排程按这个数往一天里塞节点；
     已经排好的天不会自动重排，只影响之后铺的天数。」、取消/保存。
   - 保存走 `setPlanDailyMinutes`（见 `plan-backend.md`），成功后关弹窗并 `refreshPlan()`。
   - 运行时：`planSettingsOpen`、`planDailyDraft`、`openPlanSettings/closePlanSettings/
     bumpPlanDailyDraft/choosePlanDailyDraft/savePlanDailyMinutes`。
4. **去「最小版」**：节点行不再显示「最小版 N 分」，统一「待做」。
5. **建计划工具**：`create_learning_plan` 新增 `dailyMinutes`（15–240，×7 写进 `process`），
   第一次只建本周 + 下周两个承诺，其余单元留在待安排池；guidance 写明预计时间取 B 站分集时长。
6. **验证**：`LearningPlanServiceTest.daysArePackedUpToTheDailyBudget`（20+25 同一天、30 次日、35 再次日）、
   `setPlanDailyMinutes` 的写入/越界/事件三例；全仓 `gradlew test` 绿。
   截图：`_shots/pending-1.png`（半宽待安排卡）、`_shots/pending-3.png`（点开明细）、
   `_shots/settings-plan-5.png`（设置弹窗）。
   DB 实证：选 90 保存后 `process.weekly_capacity_minutes = 630`，`event` 新增
   `plan.capacity_changed` `{"dailyMinutes":90,"weeklyCapacityMinutes":630}`。

## 10. 2026-10-29：周滚动 + 计划节奏报告（行为变化）

1. **有承诺、还没铺到天的未来周重新作为周卡片显示**（灰卡 + 「待安排」胶囊，卡片文案说明「到当周、或者周日晚上会自动排到每一天」），
   可以点开看这周承诺了哪几个单元；下方天条暂时是空的，等它变成当周/周日自动铺。
   以前这种周整周塞进「待安排」集合，滚动排周之后会出现「排好的下周又没了」的错觉。
2. **「待安排」集合现在只装池子单元**（没被任何一周承诺收走的那批）。未铺天周的单元不再重复收进来——
   否则同一批单元会在灰卡和周卡里各出现一次。`AppRuntime.planPendingNodes = service.pool(planId)`。
3. **计划页顶部新增「计划节奏」报告条**（`PlanRhythmCard`）：系统每次在 `refreshPlan()` 里推进节奏
   （结算旧周 / 补本周下周承诺 / 生成复盘 / 铺天）后，只要有实际动作就出现一句人话 + 「知道了」；
   没有动作时页面保持安静。数据来自 `AppRuntime.planRhythmReport`（后端 `RhythmResult`）。
4. **AI 也有了维护计划的手**：对话里的 `PlanManage` 意图 + `PlanAdminTools`（读状态/排下周/勾节点/顺延/复盘/改每天投入），
   见 `docs/plan-rhythm-draft.md`。计划页本身仍然只读 view model、不做四则运算。
5. **调试用「模拟时间」横幅**（`PlanSimulatedBanner`）：开发者模式（`TRELLIS_DEV=1`）拨了应用内日期后，
   计划页顶部出现「模拟时间 · 2026-11-02（真实 …）」横幅，带 `+1 天` / `+1 周` / `退出模拟` 快捷按钮；
   拨动后 `AppRuntime.applySimulatedToday(...)` 会立刻 `refreshPlan()`，让结算/补周/复盘按新日期跑一遍。
   边界与安全门槛见 `docs/time-conventions.md` §7（默认数据目录不允许，只有 `TRELLIS_HOME` 指向演示目录才生效）。

## 11. 2026-10-31：「待处理」卡片 + 协商重排的加时偏好

1. **计划页顶部新增「待处理」卡片**（`PlanOverdueCard`）：数据来自 `AppRuntime.planOverdue`
   （后端 `LearningPlanService.overdue(planId, today)`，只读投影，不写事件）。
   - 「本周到期没做完」逐条给三个动作：**今天做**（`moveOccurrence` 到今天）、**顺延一天**
     （`moveOccurrence` 到后一天；已到周日就提示等周结算，不硬塞下周）、**跳过**
     （`skipOccurrence`，只标这一天，本周承诺不释放）。
   - 「今天能多投入？」一排 `不加时 / +30 / +60 / +90`：按「每天投入 + 加时 − 今天已排」，
     把逾期项按路线顺序补进今天；答复会写进 `study.json` 的 `catchUpMinutes`（0–120），
     下次默认带上，方便 AI 以后按这个推荐。
   - 更早欠账（`backlog`）只展示；容量够时自动被 `ensureCommitment` 收进本周/下一周。
2. **为什么没有「这周先不排 / 放弃」按钮**：活跃版本的承诺单元受 schema 触发器保护
   （`commitment_unit_no_rewrite` / `no_delete`，`PlanSchema.kt:141-147`），移出承诺要开新版本、
   换 unit id；那是「重排」不是「点一下」，留到 AI 协商重排一起做。周结算里「没做完」本来就会
   标 missed 并回欠账池，所以没有「永久放弃」。
3. **协商重排的形态（定稿，替代原来的「两套方案」）**：有未完成才问，只问一句
   「今天能不能多投入一些时间？」——够就今天补做、不顺延；不够就按路线往后几天推，
   可以每天多补一点，**优先在本周内消化**；加时偏好记进 `study.json` 供以后调整。
   AI 先读 `overdue` 真数据再问，不自己数数；聊天侧实现下一步做。
4. 手动入口 v1 只到「点按钮」；同日稍后改成拖拽（见 §12），「待处理」卡片已删。

## 12. 2026-10-31：「待处理」卡片改成拖拽重排（侧栏 → 日期）

用户反馈「点按钮」不符合手动排计划的直觉：要能把节点直接拖到想排的那一天。

- **入口**：计划标题旁「重排 · N」（N = 本周逾期 + 更早欠账）；直接拖起某天列表里的节点时侧栏自动滑开。
- **侧栏三组**（`PlanRearrange.kt` 的 `PlanRearrangeDrawer`）：本周到期没做（`planOverdue.thisWeek`，
  拖 = `moveOccurrence`）、更早欠下（`planOverdue.backlog`，拖 = `placeUnit`）、
  待安排（`planPool`，拖 = `placeUnit`）。
- **落点**：七个日期格（`DayChip`）或「当天安排」整块（= 当前选中的那天）；hover 的日期格放大 + 高亮，
  今天以前的日期变淡、不接收。
- **跨周**：一次只在同一周里挪——拖到别周的格提示「要跨周先把节点放到待安排池」；
  欠账/待安排的节点拖到下一周某天则走 `placeUnit`：往那一周的承诺里增量追加一条，再铺 occurrence。
- **排序**：当天列表按路线索引（`plan_unit.sort_order`）排，不按创建/拖动先后；同一 unit 拆分的
  occurrence 用 `created_at` 兜底。SQL 在 `PlanQueries.plannedOccurrences` / `dayItems`：
  `ORDER BY COALESCE(pu.sort_order, 2147483647), d.created_at`。
- **动效**：侧栏 `AnimatedVisibility`（滑入/淡入）；打开时内容整块让开 296dp（否则日期格被抽屉盖住，
  拖不过去）；拖起的 ghost 跟手（阴影 + 轻微放大）；列表行 `animateItem()`；落手结果提示留在侧栏底部
  （成功绿、失败红）。日期格 hover 用 `animateColorAsState` + `animateFloatAsState`。
- **提示字段**：`AppRuntime.planRearrangeHint` / `planRearrangeHintIsError`——不能复用 `planMessage`，
  因为每次 `refreshPlan()` 都会清空它；侧栏开合时清掉提示。
- 旧的 `PlanOverdueCard`（今天做/顺延一天/跳过 + 加时 chips）已删除；`planDoToday` / `planDeferOneDay` /
  `planSkipToday` / `planCatchUpToday` 仍留在 `AppRuntime`（AI 协商重排会复用同一批命令），
  `study.json` 的 `catchUpMinutes` 仍作为加时偏好保留。
- 验收：`PlanRearrangeRuntimeTest` 4 个用例（路线排序、逾期拖到某天、待安排池拖入、过去/跨周拒绝）+
  `LearningPlanPlaceUnitTest` 6 个后端用例；`features:learning-process:jvmTest` 34 个、
  `:app:desktop:test` 276 个全绿。

## 13. 2026-11-03：笔记 → 计划节点自动完成（「AI 自动完成」列表）

笔记里把某个计划节点讲清楚了，就不必再去计划页手动勾一下：知识库「保存并整理」成功后自动判一次，
满足条件的节点直接标记完成，并在计划页留一条可撤销的记录。

- **候选**：本周（`planState().week`）所有 `status=planned` 的节点，不限今天/逾期；未来周不参与。
  候选超过 20 个时先按「标题/章节里的二字片段在正文出现的次数」筛，只把最相关的送进请求。
- **触发**：`KnowledgeScreen.organizeNote` 成功分支末尾（正文 ≥400 字且有候选才发请求）；
  判定逻辑在 `PlanLink.kt`，提示词要求模型输出
  `{"completions":[{"occurrenceId","coverage","confidence","evidence","reason"}]}`。
- **自动完成条件**（全部满足）：`coverage=full`、`confidence ≥ 0.8`、`evidence` 是正文**逐字片段**
  （长度 ≥8，照 `KnowledgeGraphAi` 的写法在正文里 `contains` 校验）、节点不在屏蔽名单、同一篇笔记最多 3 个。
- **执行**：`AppRuntime.autoCompletePlanNodes` 逐条 `completeOccurrence`，`Actor.SYSTEM`、
  `origin = "knowledge.auto-complete"`；结果写账本 `<home>/plans/auto-completions.json`
  （`entries` + `blocked`，写前 `.bak`、坏文件改 `.bad-<ms>`，语义在 `AutoCompletionStore.kt`）。
  已完成或已有生效记录的节点会跳过（幂等）。
- **UI**：计划页「当天安排」卡片下方多一张「AI 自动完成」卡片（有记录或屏蔽数 >0 时才出现）：
  每条 `✔ 节点标题｜撤销`，第二行 `计划日 · 来自《笔记名》`（点这一行跳回知识库并选中证据句，
  走 `pendingKnowledgeReveal`）+ 章节 + 「看证据」折叠。发生自动完成时 `planMessage` 提示
  「AI 根据《note》自动完成了 N 个节点，可在下方「AI 自动完成」里撤销」。
- **撤销 / 屏蔽**：卡片「撤销」= `uncompleteOccurrence`（改回 planned）+ 把节点写进 `blocked`，
  以后不再自动勾；在计划页手动把自动完成改回没做，同样会进 `blocked`。「解除屏蔽（N）」清空整批。
- **桌面通知**：`UiPrefs.notifyAutoCompletion`（默认关；设置页「笔记联动」→「弹桌面通知」），
  走 `Notifier`，只在本次真的自动完成了节点时发。
- **限制**：只在笔记整理成功时判一次，不后台轮询；模型判断错了要用户撤销（撤销后该节点永久屏蔽到解除）；
  跨周节点不参与；判定依赖正文证据，证据被改写后重判会自然失效。
- 验收：`PlanLinkTest` 8 个 + `AutoCompletionStoreTest` 7 个；mock 端到端（`/tmp/mock_llm5.py`，8983：
  `kind=extract` + `kind=planlink candidates=14` → 账本写入 1 条、`plan.db` occurrence 变 `done`、
  计划页卡片刻 1 条；撤销后回 `planned` 且出现「解除屏蔽（1）」；解除后再整理会重新自动完成；
  点「来自笔记」跳回正文并选中证据）。

## 14. 2026-11-03 晚：删掉「第一周在过去 → 挪到本周」的修复机制

用户报：上周创建、本周还在进行的计划，首周必然落在过去，计划页会误弹「这份计划的第一周在过去」横幅
（这个机制原本是给「模型把周次写成上一年」兜底的，但 `planWeekCards` 会列出当前版本的全部周，含已经过去的周）。

- **删除**：`AppRuntime.planStartsInPast`、`AppRuntime.repairPastPlan()`（连同只给它用的
  `UnitDraft` / `CommitmentDraft` import）；`PlanScreen` 里的触发行与 `PlanStaleBanner`；测试 `PlanRepairTest`。
  `uiCommand` 保留（计时器开始/结束还在用），origin 从 `ui.plan.repair` 改为 `ui.plan`。
- **为什么可以删**：`advanceRhythm`（`features/learning-process/.../PlanAdvance.kt`）每周自动
  「补本周承诺 → 结算旧周（结转 ≤2 进本周）→ 补下周 → 铺天」；`LearningPlanRhythmTest` 已覆盖
  「两周没打开应用，本周照样从待安排池补齐」。正常周滚动不再需要用户手动点「挪到本周」。
- **保留**：`PlanTools.create_learning_plan` 的创建时校验——第一周必须等于本周、拒绝早于本周的 ISO 周；
  agent 新建计划排错周次时仍会直接报错（`PlanToolsTest.aPlanThatStartsNextWeekIsRejected`）。
- 验证：删后 `:app:desktop:test` 与全仓 `check` 全绿；grep 无 `planStartsInPast` / `repairPastPlan` / `PlanStaleBanner` 残留。
